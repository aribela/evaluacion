<?php
/*
 *  © 2012 Framelova. All rights reserved. Privacy Policy
 *  Creado: 05/07/2016
 *  Por: Jonathan Guerrero Perez - JGP
 *  Descripción: Values neccessary for connection
 */
$cfg_server='127.0.0.1';
$cfg_user='root';
$cfg_db='pruebas_db';
$cfg_pw='';
$siteURL='http://127.0.0.1:8080/nuxiba/';
/*CONFIGURACIONES PARA ENVIO DE EMAIL SMTP*/
/*$email_from = 'tester@framelova.info';
$name_from = 'AEET - No responder';
$smtp_host = "mail.framelova.info"; // SMTP server
$smtp_Port = 465;                    // set the SMTP port for the server
$smtp_Username = "tester@framelova.info"; // SMTP account username
$smtp_Password = "";        // SMTP account password
$smtp_SMTPSecure = 'ssl';*/


$email_from = 'tester@framelova.net';
$name_from = 'AEET - No responder';
$smtp_host = "mail.framelova.net"; // SMTP server
$smtp_Port = 465;                    // set the SMTP port for the server
$smtp_Username = "tester@framelova.net"; // SMTP account username
$smtp_Password = "";        // SMTP account password
$smtp_SMTPSecure = 'ssl';